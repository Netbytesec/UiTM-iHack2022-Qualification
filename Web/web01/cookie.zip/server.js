const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');

const app = express();

const PORT = process.env.PORT || 3000;

app.use(cookieParser());

app.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
});

app.get('/', (req, res) => {
    const cookie = req.cookies.user;
    if (cookie === 'YWRtaW4=') {           
        res.sendFile(path.join(__dirname, 'public', 'flag.html'));;                     //cookie = pandan
        return;
    }
    res.cookie('user','bm90YWRtaW4=');                               
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
